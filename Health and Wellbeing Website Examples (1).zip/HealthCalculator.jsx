import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Label } from '@/components/ui/label.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Calculator, TrendingUp } from 'lucide-react';

const HealthCalculator = () => {
  const [height, setHeight] = useState('');
  const [weight, setWeight] = useState('');
  const [bmi, setBmi] = useState(null);
  const [category, setCategory] = useState('');

  const calculateBMI = () => {
    if (height && weight) {
      const heightInMeters = parseFloat(height) / 100;
      const weightInKg = parseFloat(weight);
      const bmiValue = weightInKg / (heightInMeters * heightInMeters);
      const roundedBMI = Math.round(bmiValue * 10) / 10;
      
      setBmi(roundedBMI);
      
      if (roundedBMI < 18.5) {
        setCategory('Underweight');
      } else if (roundedBMI >= 18.5 && roundedBMI < 25) {
        setCategory('Normal weight');
      } else if (roundedBMI >= 25 && roundedBMI < 30) {
        setCategory('Overweight');
      } else {
        setCategory('Obese');
      }
    }
  };

  const getBMIColor = () => {
    if (!bmi) return 'bg-gray-100 text-gray-800';
    if (bmi < 18.5) return 'bg-blue-100 text-blue-800';
    if (bmi >= 18.5 && bmi < 25) return 'bg-green-100 text-green-800';
    if (bmi >= 25 && bmi < 30) return 'bg-yellow-100 text-yellow-800';
    return 'bg-red-100 text-red-800';
  };

  const reset = () => {
    setHeight('');
    setWeight('');
    setBmi(null);
    setCategory('');
  };

  return (
    <Card className="w-full max-w-md mx-auto bg-white shadow-lg">
      <CardHeader className="text-center">
        <div className="mx-auto mb-4 p-3 bg-gradient-to-br from-teal-50 to-blue-50 rounded-full w-fit">
          <Calculator className="h-8 w-8 text-teal-600" />
        </div>
        <CardTitle className="text-xl font-semibold text-gray-900">BMI Calculator</CardTitle>
        <CardDescription className="text-gray-600">
          Calculate your Body Mass Index to assess your health status
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="height" className="text-sm font-medium text-gray-700">
            Height (cm)
          </Label>
          <Input
            id="height"
            type="number"
            placeholder="Enter your height in cm"
            value={height}
            onChange={(e) => setHeight(e.target.value)}
            className="w-full"
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="weight" className="text-sm font-medium text-gray-700">
            Weight (kg)
          </Label>
          <Input
            id="weight"
            type="number"
            placeholder="Enter your weight in kg"
            value={weight}
            onChange={(e) => setWeight(e.target.value)}
            className="w-full"
          />
        </div>

        <div className="flex gap-2">
          <Button 
            onClick={calculateBMI} 
            className="flex-1 bg-teal-600 hover:bg-teal-700"
            disabled={!height || !weight}
          >
            <TrendingUp className="mr-2 h-4 w-4" />
            Calculate
          </Button>
          <Button 
            onClick={reset} 
            variant="outline" 
            className="border-teal-600 text-teal-600 hover:bg-teal-50"
          >
            Reset
          </Button>
        </div>

        {bmi && (
          <div className="mt-6 p-4 bg-gradient-to-br from-gray-50 to-blue-50 rounded-lg">
            <div className="text-center">
              <div className="text-2xl font-bold text-gray-900 mb-2">
                Your BMI: {bmi}
              </div>
              <Badge className={`${getBMIColor()} mb-3`}>
                {category}
              </Badge>
              <div className="text-sm text-gray-600">
                <p className="mb-2">BMI Categories:</p>
                <div className="text-xs space-y-1">
                  <div>Underweight: Below 18.5</div>
                  <div>Normal weight: 18.5 - 24.9</div>
                  <div>Overweight: 25 - 29.9</div>
                  <div>Obese: 30 and above</div>
                </div>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default HealthCalculator;

