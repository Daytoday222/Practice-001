import multivitaminImg from '../assets/multivitamin.jpg';
import vitaminAImg from '../assets/vitamin-a.jpg';
import heartSupportImg from '../assets/heart-support.jpg';
import fitnessEquipmentImg from '../assets/fitness-equipment.jpg';
import homeGymImg from '../assets/home-gym.png';
import wellnessProductsImg from '../assets/wellness-products.jpg';
import superGreensImg from '../assets/super-greens.jpg';
import organicProductsImg from '../assets/organic-products.png';

export const featuredProducts = [
  {
    id: 1,
    name: "10X Health Optimize Methylated Multivitamin",
    description: "34-in-1 formula with 800 mcg of Vitamin B12, Vitamin E, 5-MTHF, B Complex, NAC for optimal health support.",
    price: 49.99,
    originalPrice: 59.99,
    discount: 17,
    category: "Supplements",
    rating: 5,
    reviews: 1247,
    image: multivitaminImg,
    inStock: true,
    featured: true
  },
  {
    id: 2,
    name: "Heart Support Supplement",
    description: "Promotes cardiovascular health, supports healthy triglyceride and homocysteine levels with 22 premium ingredients.",
    price: 39.99,
    originalPrice: 49.99,
    discount: 20,
    category: "Heart Health",
    rating: 5,
    reviews: 892,
    image: heartSupportImg,
    inStock: true,
    featured: true
  },
  {
    id: 3,
    name: "Premium Home Gym Equipment Set",
    description: "Complete home fitness solution with adjustable weights, resistance bands, and workout guide for all fitness levels.",
    price: 299.99,
    originalPrice: 399.99,
    discount: 25,
    category: "Fitness Equipment",
    rating: 4,
    reviews: 456,
    image: homeGymImg,
    inStock: true,
    featured: true
  },
  {
    id: 4,
    name: "Organic Super Greens Powder",
    description: "Full of superfood vitamins & minerals, fruits & vegetables. Greens powder for bloating and digestive support.",
    price: 34.99,
    originalPrice: 44.99,
    discount: 22,
    category: "Superfoods",
    rating: 5,
    reviews: 678,
    image: superGreensImg,
    inStock: true,
    featured: true
  }
];

export const topSellingProducts = [
  {
    id: 5,
    name: "NOW Vitamin A 10,000 IU",
    description: "Eye health essential nutrition supplement with 100 softgels for optimal vision support and immune function.",
    price: 12.99,
    category: "Vitamins",
    rating: 4,
    reviews: 2341,
    image: vitaminAImg,
    inStock: true
  },
  {
    id: 6,
    name: "Professional Fitness Equipment",
    description: "Commercial-grade fitness equipment for serious athletes and fitness enthusiasts. Built for durability and performance.",
    price: 199.99,
    originalPrice: 249.99,
    discount: 20,
    category: "Fitness Equipment",
    rating: 5,
    reviews: 1567,
    image: fitnessEquipmentImg,
    inStock: true
  },
  {
    id: 7,
    name: "Wellness Essentials Collection",
    description: "Curated collection of the best wellness products including aromatherapy, skincare, and relaxation items.",
    price: 89.99,
    category: "Wellness",
    rating: 4,
    reviews: 934,
    image: wellnessProductsImg,
    inStock: true
  },
  {
    id: 8,
    name: "Organic Health Products Bundle",
    description: "Premium organic health products including teas, kitchen essentials, and herbal supplements for natural wellness.",
    price: 67.99,
    originalPrice: 79.99,
    discount: 15,
    category: "Organic",
    rating: 5,
    reviews: 1123,
    image: organicProductsImg,
    inStock: false
  },
  {
    id: 9,
    name: "Advanced Multivitamin Complex",
    description: "Comprehensive daily multivitamin with essential nutrients, minerals, and antioxidants for overall health.",
    price: 29.99,
    category: "Supplements",
    rating: 4,
    reviews: 1876,
    image: multivitaminImg,
    inStock: true
  },
  {
    id: 10,
    name: "Cardiovascular Support Formula",
    description: "Scientifically formulated to support heart health with CoQ10, omega-3, and other heart-healthy nutrients.",
    price: 45.99,
    category: "Heart Health",
    rating: 5,
    reviews: 756,
    image: heartSupportImg,
    inStock: true
  }
];

export const allProducts = [...featuredProducts, ...topSellingProducts];

