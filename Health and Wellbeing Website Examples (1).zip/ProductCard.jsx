import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Star, ShoppingCart, Heart } from 'lucide-react';

const ProductCard = ({ product, featured = false }) => {
  const renderStars = (rating) => {
    return [...Array(5)].map((_, i) => (
      <Star 
        key={i} 
        className={`h-4 w-4 ${i < rating ? 'text-yellow-400 fill-current' : 'text-gray-300'}`} 
      />
    ));
  };

  return (
    <Card className={`group hover:shadow-xl transition-all duration-300 hover:-translate-y-2 border-0 bg-white/90 backdrop-blur-sm ${featured ? 'ring-2 ring-teal-500' : ''}`}>
      <CardHeader className="relative p-0">
        {featured && (
          <Badge className="absolute top-3 left-3 z-10 bg-teal-600 text-white">
            Featured
          </Badge>
        )}
        {product.discount && (
          <Badge className="absolute top-3 right-3 z-10 bg-red-500 text-white">
            -{product.discount}%
          </Badge>
        )}
        <div className="relative overflow-hidden rounded-t-lg">
          <img 
            src={product.image} 
            alt={product.name}
            className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
          />
          <Button 
            variant="ghost" 
            size="sm" 
            className="absolute top-3 right-3 bg-white/80 hover:bg-white text-gray-600 hover:text-red-500 rounded-full p-2"
          >
            <Heart className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-4">
        <div className="mb-2">
          <Badge variant="outline" className="text-xs text-teal-600 border-teal-600">
            {product.category}
          </Badge>
        </div>
        <CardTitle className="text-lg font-semibold text-gray-900 mb-2 line-clamp-2">
          {product.name}
        </CardTitle>
        <CardDescription className="text-gray-600 text-sm mb-3 line-clamp-2">
          {product.description}
        </CardDescription>
        
        <div className="flex items-center mb-3">
          <div className="flex items-center mr-2">
            {renderStars(product.rating)}
          </div>
          <span className="text-sm text-gray-600">({product.reviews})</span>
        </div>

        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            {product.originalPrice && (
              <span className="text-sm text-gray-500 line-through">
                ${product.originalPrice}
              </span>
            )}
            <span className="text-xl font-bold text-teal-600">
              ${product.price}
            </span>
          </div>
          {product.inStock ? (
            <Badge className="bg-green-100 text-green-800 hover:bg-green-200">
              In Stock
            </Badge>
          ) : (
            <Badge className="bg-red-100 text-red-800 hover:bg-red-200">
              Out of Stock
            </Badge>
          )}
        </div>

        <div className="flex gap-2">
          <Button 
            className="flex-1 bg-teal-600 hover:bg-teal-700 text-white"
            disabled={!product.inStock}
          >
            <ShoppingCart className="mr-2 h-4 w-4" />
            Add to Cart
          </Button>
          <Button variant="outline" className="border-teal-600 text-teal-600 hover:bg-teal-50">
            View Details
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default ProductCard;

