import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Button } from '@/components/ui/button.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Label } from '@/components/ui/label.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { Mail, CheckCircle, Send } from 'lucide-react';

const NewsletterSignup = () => {
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (email && name) {
      setIsLoading(true);
      // Simulate API call
      setTimeout(() => {
        setIsSubmitted(true);
        setIsLoading(false);
        setEmail('');
        setName('');
      }, 1500);
    }
  };

  const reset = () => {
    setIsSubmitted(false);
    setEmail('');
    setName('');
  };

  if (isSubmitted) {
    return (
      <Card className="w-full max-w-md mx-auto bg-gradient-to-br from-green-50 to-teal-50 border-green-200">
        <CardContent className="p-6 text-center">
          <div className="mx-auto mb-4 p-3 bg-green-100 rounded-full w-fit">
            <CheckCircle className="h-8 w-8 text-green-600" />
          </div>
          <h3 className="text-lg font-semibold text-gray-900 mb-2">
            Welcome to HealthWell!
          </h3>
          <p className="text-gray-600 mb-4">
            Thank you for subscribing! You'll receive our latest health tips and wellness insights.
          </p>
          <Button 
            onClick={reset} 
            variant="outline" 
            className="border-green-600 text-green-600 hover:bg-green-50"
          >
            Subscribe Another Email
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full max-w-md mx-auto bg-white shadow-lg">
      <CardHeader className="text-center">
        <div className="mx-auto mb-4 p-3 bg-gradient-to-br from-teal-50 to-blue-50 rounded-full w-fit">
          <Mail className="h-8 w-8 text-teal-600" />
        </div>
        <CardTitle className="text-xl font-semibold text-gray-900">Stay Updated</CardTitle>
        <CardDescription className="text-gray-600">
          Get the latest health tips and wellness insights delivered to your inbox
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="newsletter-name" className="text-sm font-medium text-gray-700">
              Full Name
            </Label>
            <Input
              id="newsletter-name"
              type="text"
              placeholder="Enter your full name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full"
              required
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="newsletter-email" className="text-sm font-medium text-gray-700">
              Email Address
            </Label>
            <Input
              id="newsletter-email"
              type="email"
              placeholder="Enter your email address"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full"
              required
            />
          </div>

          <Button 
            type="submit" 
            className="w-full bg-teal-600 hover:bg-teal-700"
            disabled={!email || !name || isLoading}
          >
            {isLoading ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Subscribing...
              </>
            ) : (
              <>
                <Send className="mr-2 h-4 w-4" />
                Subscribe to Newsletter
              </>
            )}
          </Button>

          <div className="text-center">
            <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-200">
              Weekly Health Tips • No Spam • Unsubscribe Anytime
            </Badge>
          </div>
        </form>
      </CardContent>
    </Card>
  );
};

export default NewsletterSignup;

